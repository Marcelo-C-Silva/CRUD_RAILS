class AdminController < ActionController::Base
    def index
    end
end