class Student < ApplicationRecord

validates :name, presence: true
validates :email, presence: true, uniqueness: true, format: { with: URI::MailTo::EMAIL_REGEXP }
validates :weight, presence: true, numericality: { greater_than: 0 }
validates :height, presence: true, numericality: { greater_than: 0 }

  before_save :calculate_bmi


  private

  def calculate_bmi
    if weight.present? && height.present?
      self.bmi = weight / (height / 100) ** 2 
    end
  end
end
