Rails.application.routes.draw do
    root 'home#index'
    resources :students
    resources :modalities
    resources :admin
end
