class AddBmiToStudents < ActiveRecord::Migration[7.1]
  def change
    add_column :students, :bmi, :float
  end
end
