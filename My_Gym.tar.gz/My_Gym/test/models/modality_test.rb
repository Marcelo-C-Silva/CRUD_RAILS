require "test_helper"

class ModalityTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
